package Classes;

/**
 * The ModuleType class contains Enumerated types representing the Module type for a Programme paper.
 * @author Bond Trinh 18026893
 **/

public enum ModuleType
{
    SELF_STUDY, TAUGHT, PROJECT, CLIENT_PROJECT;
}