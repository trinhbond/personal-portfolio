var xhr = createRequest();
/*
    Name: Bond Trinh
    Student ID: 18026893

    This function retrieves the form input from booking.html and sends it to a
    dataSource (booking.php) wher the input is displayed on a div where and id is called
    "reference".
*/
function getData(dataSource, divID, cname, phone, unumber, snumber, stname, sbname, dsbname, date, time) 
{
  if (xhr) 
  {
    var obj = document.getElementById(divID);
    var requestbody =
      "cname=" + encodeURIComponent(cname) + "&phone=" + encodeURIComponent(phone)
      + "&unumber=" + encodeURIComponent(phone) + "&unumber=" + encodeURIComponent(unumber) + 
      "&snumber=" + encodeURIComponent(snumber) + "&stname=" + encodeURIComponent(stname) + 
      "&sbname=" + encodeURIComponent(sbname) + "&dsbname=" + encodeURIComponent(dsbname) + 
      "&date=" + encodeURIComponent(date) + "&time=" + encodeURIComponent(time);
    xhr.open("POST", dataSource, true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () 
    {
      alert(xhr.readyState); // to let us see the state of the computation
      if (xhr.readyState == 4 && xhr.status == 200) 
      {
        obj.innerHTML = xhr.responseText;
      } // end if
    }; // end anonymous call-back function
    xhr.send(requestbody);
  } // end if
} // end function getData()
