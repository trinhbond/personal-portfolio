/*
    Name: Bond Trinh
    Student ID: 18026893

    This function creates an XMLHttpRequest object to communicate with
    servers and retrieve data from URL's
    without refreshing.
*/

function createRequest() 
{
    var xhr = false;  
    if (window.XMLHttpRequest) 
    {
        xhr = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) 
    {
        xhr = new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xhr;
} // end function createRequest()
