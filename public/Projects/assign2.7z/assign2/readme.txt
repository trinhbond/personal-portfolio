Files
---------
admin.html
admin.css
admin.js
admin.php
booking.html
booking.css
booking.js
booking.php
xhr.js
mysqlcommand.txt
readme.txt
---------

How to use the system
---------------------

On the Booking page you can book a cab by filling in a form. In order to submit a successful booking:
	- You must enter a customer name.
	- You must enter a phone number where the number of digits is between 10 and 12.
	- Unit number is optional.
	- You must enter a Street Number.
	- You must enter a Street Name.
	- Destination Suburb is optional.
	- You must choose a Pick-up date. The date must be within or after the current date.
	- You must choose a Pick-up time. The time must be within or after the current date.

	Once your booking has been confimred, you will receive a booking reference number and the details of your bookings in return.


On the Admin page, you can search for a booking request that you have previously made. 
All you need to do is enter your booking reference number in the input form and click "Search."

	- If your search result matches a booking, a table displaying the details of the booking will be returned.
	  Otherwise, an appropriate will be displayed to show that there are no matches.

	- If you choose not to enter a booking reference number, you may click "Search" and a list of booking requests made for within the next 2 hours will be displayed. 
	  If there are no bookings, an appropriate message will be displayed.