package Classes;

/**
 * The Result class stores Module and Grade objects,
 * includes a constructor to initialise instance variables, get and set methods, and returns a toString method representing the Result object.
 * @author Bond Trinh 18026893
 **/

public class Result
{
    private Grade grade;
    private Module module;

    public Result(Grade grade, Module module)
    {
        this.grade = grade;
        this.module = module;
    }

    public Grade getGrade()
    {
        return (grade);
    }

    public Module getModule()
    {
        return (module);
    }

    /**
     * @Return toString method returns the paper code and the grade for the transcript.
     **/
    public String toString()
    {
        return (this.module.getCode() +  " " + this.getGrade());
    }
}