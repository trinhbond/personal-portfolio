package Classes;

/**
 * The Level class stores a list of 3 constants for the Enumeration "Level" that correspond to the level of the Programme's papers.
 * @author Bond Trinh 18026893
 **/

public enum Level
{
    ONE, TWO, THREE;
}