package Classes;

/**
 * The Module class maintains instance variables for code, title, ModuleType and Level.
 * @author Bond Trinh 18026893
 **/

public class Module
{
    private String code;
    private String title;
    private ModuleType type;
    private Level level;

    /**
     * A module constructor to initialise and instantiate variables
     **/

    public Module(String title, String code, Level level, ModuleType type)
    {
        this.code = code;
        this.title = title;
        this.level = level;
        this.type = type;
    }

    public String getCode()
    {
        return (code);
    }

    public ModuleType getType()
    {
        return (type);
    }

    public Level getLevel()
    {
        return (level);
    }

    /**
     * toString method for Module class.
     * @return Returns a text to the output screen.
     */
    @Override
    public String toString()
    {
        return (this.getCode() + this.getType());
    }
}