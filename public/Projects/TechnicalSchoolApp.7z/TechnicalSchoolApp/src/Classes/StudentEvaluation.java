package Classes;

/**
 * The StudentEvaluation class evaluates a student's transcript to determine if that student satisfies the criteria for Certification.
 * The student's detail's are printed and is evaluated using the isCertified method in the TechnicalSchool class.
 * @author Bond Trinh 18026893
 **/

public class StudentEvaluation
{
    public static Student Robin()
    {
        Student robin = new Student("Robin");
        TechnicalSchool isCertified = new TechnicalSchool();

        robin.addResultToTranscript(isCertified.lookup("PROG101"), Grade.C);
        robin.addResultToTranscript(isCertified.lookup("DATA222"), Grade.C);
        robin.addResultToTranscript(isCertified.lookup("INSY313"), Grade.C_PLUS);
        robin.addResultToTranscript(isCertified.lookup("WEBS332"), Grade.C_PLUS);
        robin.addResultToTranscript(isCertified.lookup("TECH103"), Grade.C_PLUS);
        robin.addResultToTranscript(isCertified.lookup("MODC233"), Grade.C_MINUS);
        robin.addResultToTranscript(isCertified.lookup("TOPG233"), Grade.C_MINUS);
        robin.addResultToTranscript(isCertified.lookup("PROJ399"), Grade.A_PLUS);

        return (robin);
    }

    public static Student Kate()
    {
        Student kate = new Student("Kate");
        TechnicalSchool isCertified = new TechnicalSchool();

        kate.addResultToTranscript(isCertified.lookup("PROG101"), Grade.A_PLUS);
        kate.addResultToTranscript(isCertified.lookup("STAT102"), Grade.A_MINUS);
        kate.addResultToTranscript(isCertified.lookup("TECH103"), Grade.B_PLUS);
        kate.addResultToTranscript(isCertified.lookup("MODC233"), Grade.A);
        kate.addResultToTranscript(isCertified.lookup("TOPG233"), Grade.C);
        kate.addResultToTranscript(isCertified.lookup("DATA222"), Grade.A);
        kate.addResultToTranscript(isCertified.lookup("INSY313"), Grade.B_PLUS);
        kate.addResultToTranscript(isCertified.lookup("WEBS332"), Grade.A_MINUS);
        kate.addResultToTranscript(isCertified.lookup("PROJ399"), Grade.B);
        kate.addResultToTranscript(isCertified.lookup("EXTO396"), Grade.B);

        return (kate);
    }

    public static Student Axel()
    {
        Student axel = new Student("Axel");
        TechnicalSchool isCertified = new TechnicalSchool();

        axel.addResultToTranscript(isCertified.lookup("PROG101"), Grade.B_PLUS);
        axel.addResultToTranscript(isCertified.lookup("STAT102"), Grade.C);
        axel.addResultToTranscript(isCertified.lookup("DATA222"), Grade.A);
        axel.addResultToTranscript(isCertified.lookup("INSY313"), Grade.A_MINUS);
        axel.addResultToTranscript(isCertified.lookup("WEBS332"), Grade.A);
        axel.addResultToTranscript(isCertified.lookup("TECH103"), Grade.D);
        axel.addResultToTranscript(isCertified.lookup("MODC233"), Grade.B);
        axel.addResultToTranscript(isCertified.lookup("TOPG233"), Grade.B);
        axel.addResultToTranscript(isCertified.lookup("PROJ399"), Grade.C_MINUS);
        axel.addResultToTranscript(isCertified.lookup("EXTO396"), Grade.C);

        return (axel);
    }

    public static Student Jim()
    {
        Student jim = new Student("Jim");
        TechnicalSchool isCertified = new TechnicalSchool();

        jim.addResultToTranscript(isCertified.lookup("PROG101"), Grade.A);
        jim.addResultToTranscript(isCertified.lookup("STAT102"), Grade.B_PLUS);
        jim.addResultToTranscript(isCertified.lookup("DATA222"), Grade.C_PLUS);
        jim.addResultToTranscript(isCertified.lookup("PROG202"), Grade.C);
        jim.addResultToTranscript(isCertified.lookup("INSY313"), Grade.C);
        jim.addResultToTranscript(isCertified.lookup("WEBS332"), Grade.C_PLUS);
        jim.addResultToTranscript(isCertified.lookup("TECH103"), Grade.C_MINUS);
        jim.addResultToTranscript(isCertified.lookup("THEO111"), Grade.D);
        jim.addResultToTranscript(isCertified.lookup("MODC233"), Grade.A_PLUS);
        jim.addResultToTranscript(isCertified.lookup("TOPG233"), Grade.A);
        jim.addResultToTranscript(isCertified.lookup("LOGI321"), Grade.B);
        jim.addResultToTranscript(isCertified.lookup("PROJ399"), Grade.B_MINUS);
        jim.addResultToTranscript(isCertified.lookup("EXTO396"), Grade.A_PLUS);

        return (jim);
    }

    public static Student Andre()
    {
        Student andre = new Student("Andre");
        TechnicalSchool isCertified = new TechnicalSchool();

        andre.addResultToTranscript(isCertified.lookup("MODC233"), Grade.A);
        andre.addResultToTranscript(isCertified.lookup("DATA222"), Grade.A_PLUS);
        andre.addResultToTranscript(isCertified.lookup("EXTO396"), Grade.C_PLUS);
        andre.addResultToTranscript(isCertified.lookup("TECH103"), Grade.B_MINUS);
        andre.addResultToTranscript(isCertified.lookup("THEO111"), Grade.B);
        andre.addResultToTranscript(isCertified.lookup("WEBS332"), Grade.C_PLUS);
        andre.addResultToTranscript(isCertified.lookup("LOGI321"), Grade.C_PLUS);
        andre.addResultToTranscript(isCertified.lookup("STAT102"), Grade.A);
        andre.addResultToTranscript(isCertified.lookup("PROJ399"), Grade.A);
        andre.addResultToTranscript(isCertified.lookup("TOPG233"), Grade.D);
        andre.addResultToTranscript(isCertified.lookup("PROG202"), Grade.C);

        return (andre);
    }

    public static Student Hannibal()
    {
        Student hannibal = new Student("Hannibal");
        TechnicalSchool isCertified = new TechnicalSchool();

        hannibal.addResultToTranscript(isCertified.lookup("PROJ399"), Grade.B);
        hannibal.addResultToTranscript(isCertified.lookup("WEBS332"), Grade.B_MINUS);
        hannibal.addResultToTranscript(isCertified.lookup("TECH103"), Grade.B_PLUS);
        hannibal.addResultToTranscript(isCertified.lookup("DATA222"), Grade.C);
        hannibal.addResultToTranscript(isCertified.lookup("THEO111"), Grade.D);
        hannibal.addResultToTranscript(isCertified.lookup("STAT102"), Grade.C_MINUS);
        hannibal.addResultToTranscript(isCertified.lookup("TOPG233"), Grade.A);
        hannibal.addResultToTranscript(isCertified.lookup("PROG202"), Grade.A_MINUS);
        hannibal.addResultToTranscript(isCertified.lookup("INSY313"), Grade.D);
        hannibal.addResultToTranscript(isCertified.lookup("PROG101"), Grade.A);

        return (hannibal);
    }

    /**
     *
     * The main method is used to call the functions that allow a student's transcript to be evaluated and return results,
     * such as the grade of the paper, and whether or not a student is certified.
     */

    public static void main(String[] args)
    {
        TechnicalSchool aut = new TechnicalSchool();

        System.out.println(Robin());
        System.out.println(aut.isCertified(Robin()));

        System.out.println("\n");

        System.out.println(Kate());
        System.out.println(aut.isCertified(Kate()));

        System.out.println("\n");

        System.out.println(Axel());
        System.out.println(aut.isCertified(Axel()));

        System.out.println("\n");

        System.out.println(Jim());
        System.out.println(aut.isCertified(Jim()));

        System.out.println("\n");

        System.out.println(Andre());
        System.out.println(aut.isCertified(Andre()));

        System.out.println("\n");

        System.out.println(Hannibal());
        System.out.println(aut.isCertified(Hannibal()));
    }
}