<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet">

    <title>Status Posting System</title>
    <style type="text/css">
        * {
            margin: 0;
            font-family: 'Montserrat', sans-serif;
        }

        html {
            height: 100%;
        }

        body {
            min-height: 100%;
        }

        .container-fluid {
            width: 100%;
        }

        ul {
            padding-top: 5%;
            padding-bottom: 5%;
            font-weight: bold;
        }

        .nav {
            background-color: transparent;
            position: relative;
            padding: 25px 0 25px 0;
            background-color: rgba(220, 220, 220, 0);
            width: 96%;
            display: flex;
            margin-left: auto;
            margin-right: auto;
            left: 0;
            right: 0;
        }

        li {
            display: inline;
            margin-right: 14px;
        }

        .nav-item {
            font-size: 16px;
        }

        .nav-link {
            color: black;
            font-weight: 600;
        }

        .nav-link:hover {
            text-decoration: underline;
            text-underline-offset: 5px;

        }

        .content {
            width: 96%;
            height: 80%;
            display: flex;
            position: absolute;
            margin-left: auto;
            margin-right: auto;
            left: 0;
            right: 0;
            justify-content: center;
            background-color: beige;
        }

        footer {
            position: absolute;
            width: 100%;
            bottom: 8px;
            margin-left: 0;
            margin-right: 0;
            left: 0;
            right: 0;
            justify-content: center;
            display: flex;
            padding: 0;
        }

        h1 {
            font-weight: 800;
            position: absolute;
            left: 17.5%;
            top: 15%;
        }

        form {
            width: 65%;
            position: absolute;
            margin-left: auto;
            margin-right: auto;
            left: 0;
            right: 0;
            justify-content: center;
            top: 175px;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/index.html">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/about.html">About this assignment</a>
            </li>
            <li class="nav-item" style="text-decoration: underline; text-underline-offset: 5px;">
                <a class="nav-link" href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/poststatusform.php">Post a new status</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/searchstatusform.html">Search a post</a>
            </li>
        </ul>
    </div>
    <div class="content">
        <h1>Post Status Form</h1>
        <form action="poststatusprocess.php" method="post">
            <span style="display: block; padding-bottom: 1rem;">
                <label>Status Code (required):</label>
                <input placeholder="#S0000" class="form-control" type="text" name="statuscode"/>
            </span>
            <span style="display: block; padding-bottom: 1rem;">
                <label>Status (required):</label>
                <input placeholder="Enter a status..." type="text" class="form-control" name="status"/>
            </span>
            <div>
                <label>Share to:</label>
                <div>
                    <input class="form-check-input" type="radio" name="share" value="Public">
                    <label>Public</label>
                </div>
                <div>
                    <input class="form-check-input" type="radio" name="share" value="Friends">
                    <label>Friends</label>
                </div>
                <div style="display: block; padding-bottom: 1rem;">
                    <input class="form-check-input" type="radio" name="share" value="Only Me">
                    <label>Only Me</label>
                </div>
            </div>
            <div class="container_date" style="display: block; padding-bottom: 1rem;">
                <label>Date:</label>
                <input type="date" name="date" value="<?php echo date('Y-m-d'); ?>"/>
            </div>
            <div class="container" style="display: block; padding-bottom: 1rem;">
                <label>Permission Type:</label>
                <div style="display: inline-block;">
                    <input class="form-check-input" type="checkbox" name="permission[]" value="Allow Like">
                    <label>Allow Like</label>
                </div>
                <div style="display: inline-block;">
                    <input class="form-check-input" type="checkbox" name="permission[]" value="Allow Comment">
                    <label>Allow Comment</label>
                </div>
                <div style="display: inline-block;">
                    <input class="form-check-input" type="checkbox" name="permission[]" value="Allow Share">
                    <label>Allow Share</label>
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-sm" href="#" value="submit">Submit</button>
            <button type="reset" class="btn btn-primary btn-sm">Reset</button>
    </div>
    </div>
    </form>
    </div>
</body>
<footer>
    <p class="copyright">&copy; Bond Trinh 2022 | Web Development Assignment 1</p>
</footer>

</html>