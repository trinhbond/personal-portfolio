package Classes;

/**
 * The Student class maintains an array of results called a transcript.
 * It contains a method which creates a Result object and adds it to the end of the transcript, updating its results,
 * and another method to return the Result objects as an array.
 * @author Bond Trinh 18026893
 **/

public class Student
{
    private String studentName;
    private final static int MAX_TRANSCRIPT_LENGTH = 20;
    private int numberOfResults;
    private Result transcript[];

    /**
     * A constructor which uses studentName as a parameter, initialises the studentName value, and the transcript as a new array.
     **/

    public Student(String studentName)
    {
        this.studentName = studentName;
        this.transcript = new Result[MAX_TRANSCRIPT_LENGTH];
    }

    /**
     * addResultToTranscript creates a Result object and updates the results of a Student via the numberOfResults variable.
     * @return Returns nothing if the transcript is full, and cannot be updated, otherwise the numberOfResults is updated.
     **/

    public void addResultToTranscript(Module modules, Grade grades)
    {
        Result resultObjects = new Result(grades, modules);

        if (this.transcript[numberOfResults] == null)
        {
            this.transcript[this.numberOfResults] = resultObjects;
            this.numberOfResults++;
        }
        else if (this.numberOfResults == this.transcript.length)
        {
            return;
        }
    }
    /**
     * @return Returns an array of Result objects.
     * The method contains a for loop which iterates through the array to ensure it does not contain null entries.
     **/

    public Result[] getTranscript()
    {
        Result[] resultTranscript = new Result[this.numberOfResults];

        for (int i = 0; i < resultTranscript.length; i++)
        {
            if (transcript[i] != null)
            {
                resultTranscript[i] = this.transcript[i];
            }
        }
        return (resultTranscript);
    }

    /**
     * Prints the transcript of a student.
     */
    @Override
    public String toString()
    {
        System.out.println("Transcript for " + studentName);
        for (int i = 0; i < numberOfResults; i++)
        {
            System.out.println(getTranscript()[i]);
        }
        return ("");
    }
}