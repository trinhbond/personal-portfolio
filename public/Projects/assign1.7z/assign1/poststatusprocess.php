<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>Status Posting System</title>
    <style type="text/css">
        * {
            font-family: 'Montserrat', sans-serif;
            margin: 0;
        }

        html {
            height: 100%;
        }

        body {
            min-height: 100%;
        }

        .container-fluid {
            width: 100%;
        }

        ul {
            padding-top: 5%;
            padding-bottom: 5%;
            font-weight: bold;
        }

        .nav {
            background-color: transparent;
            position: relative;
            padding: 25px 0 25px 0;
            background-color: rgba(220, 220, 220, 0);
            width: 96%;
            display: flex;
            margin-left: auto;
            margin-right: auto;
            left: 0;
            right: 0;
        }

        li {
            display: inline;
            margin-right: 14px;
        }

        .nav-item {
            font-size: 16px;
        }

        .nav-link {
            color: black;
            font-weight: 600;
        }

        .nav-link:hover {
            text-decoration: underline;
            text-underline-offset: 5px;
        }

        .content {
            width: 96%;
            position: absolute;
            margin: auto;
            margin-left: auto;
            margin-right: auto;
            left: 0;
            right: 0;
            justify-content: center;
            background-color: beige;
            padding: 25px 25px 25px 25px;
        }

        footer {
            position: absolute;
            width: 100%;
            bottom: 8px;
            margin-left: 0;
            margin-right: 0;
            left: 0;
            right: 0;
            justify-content: center;
            display: flex;
            padding: 0;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/index.html">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/about.html">About this assignment</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/poststatusform.php">Post a new status</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/searchstatusform.html">Search a post</a>
            </li>
        </ul>
    </div>

    <div class="content">
        <h1>Post Status Process</h1>
        <?php
        require_once("../../db_connection.php");

        // Retrieving the form data from the post status form
        $status_code = $_POST["statuscode"];
        $status = $_POST["status"];
        $share = $_POST["share"];
        $date = $_POST["date"];
        $dateTime = DateTime::createFromFormat('d/m/Y', $date);
        $formatted_date = date('d/m/Y', strtotime($date));
        $permission_type = implode(', ', $_POST["permission"]);
        // The sql query from $check retrieves all the statuscode's that exist in the table and the $result variable returns the number of rows that exist for the attribute
        $check = mysqli_query($conn, "select * from posts where statuscode='$status_code'");
        $result = mysqli_num_rows($check);
	$length = strlen($status_code);

        // The conditional statement below captures all the validation that is required in order for the data to be saved into a database table, i.e. unique status code, non-empty status etc...
        // If the data is valid, it will be saved into a table that is created on the fly if it does not exist, otherwise an appropriate error message will display what is wrong with the data form
        if (preg_match("/S\d{4}/", $status_code) && ($result == 0) && ($length == 5) && (trim($status) != '') && (trim($share) != '') && (DateTime::createFromFormat('Y-m-d', $date) !== false) && (trim($permission_type) != '')) 
        {
            $querycheck = "SELECT * from posts";
            $query_result = $conn->query($querycheck);

            // If the query performed from $query_result is successful, insert the data into a table
            if ($query_result !== FALSE) 
            {
                $sql = "INSERT INTO posts (statuscode, status, share, date, permission) VALUES ('$status_code', '$status', '$share', '$date', '$permission_type')";

                // If the data has been successfully posted to the database table, send out a success alert, otherwise display an error message
                if ($conn->query($sql) === TRUE) 
                {
                    ?>
                        <div class="alert alert-success" role="alert">Congratulations! The status has been posted!</div>
                    <?
                } else
                {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                    ?>
                    <div class="alert alert-danger" role="alert">
                        <h4 class="alert-heading">Error</h4>
                        <hr>
                        <p class="mb-0">Error:  <?=$sql?> <br> <?= $conn->error ?></p>
                    </div>
                    <?
                }
            } 
            else 
            {
                $sql = "CREATE TABLE posts (statuscode VARCHAR(5), status VARCHAR(255) NOT NULL, share VARCHAR(50) NOT NULL, date DATE NOT NULL, permission VARCHAR(255))";
                if ($conn->query($sql) === TRUE) 
                {
                    echo "Table posts created successfully";
                } 
                else 
                {
                ?>
                 <div class="alert alert-danger" role="alert">
                     <h4 class="alert-heading">Error 4: Unspecified share status</h4>
                     <hr>
                     <p class="mb-0">Error creating table</p>
                 </div>
                <?
                }
            }
        }
        if ($result > 0) 
        {
            ?>
            <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading">Error code 1: Duplicate status code</h4>
                <hr>
                <p class="mb-0">The status code you entered &lsquo;<?= $status_code ?>&rsquo; already exists. Please try another one!</p>
            </div>
            <?
        }
	if ((preg_match("/S\d{4}/", $status_code) == false) || ($length != 5) || (trim($status_code) == ''))
        {	
             ?>
             <div class="alert alert-danger" role="alert">
                 <h4 class="alert-heading">Error 2: Incorrect status code format</h4>
                 <hr>
                 <p class="mb-0">Status code: Wrong format! The status code must start with an &lsquo;S&rsquo; followed by four digits, like &lsquo;S0001&rsquo;</p>
             </div>
             <?
	}
	if (preg_match('/[\'^�$%&*()}{@#~?><>|=_+�-]/', $status))  
        {
            ?>
            <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading">Error 4: Wrong format status</h4>
                <hr>
                <p class="mb-0">Status: Your status is in a wrong format! The status can only contain alphanumericals and spaces, comma, period, exclamation point and question mark and cannot be blank!</p>
            </div>
            <?
        }
        if (trim($status) == '') 
	{
            ?>
            <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading">Error 4: Empty status</h4>
                <hr>
                <p class="mb-0">Status: Your status is in a wrong format! The status can only contain alphanumericals and spaces, comma, period, exclamation point and question mark and cannot be blank!</p>
            </div>
            <?
        }
        if (trim($share) == '') 
        {
            ?>
            <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading">Error 5: Unspecified share status</h4>
                <hr>
                <p class="mb-0">Share: You did not specify who you want to share your status with. Please try again!</p>
            </div>
            <?
        }
        if (DateTime::createFromFormat('Y-m-d', $date) == false) 
        {
            ?>
            <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading">Error 6: Invalid date</h4>
                <hr>
                <p class="mb-0">The date you entered &lsquo; <?= $date ?> &rsquo; is not valid date. Please try again!</p>
            </div>
            <?
        }
        if (trim($permission_type) == '') 
        {
            ?>
            <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading">Error 7: Unspecified permission type</h4>
                <hr>
                <p class="mb-0">Permission: You did not specify a permission type. Please try again!</p>
            </div>
            <?
        }
        ?>
         <a href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/index.html">Home Page</a>
         <a href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/poststatusform.php" style="float:right;">Back to Post Status Form</a>
    </div>

</body>

</html>