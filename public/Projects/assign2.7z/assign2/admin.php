<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<!-- 
    Name: Bond Trinh
    Student ID: 18026893

    This file handles the backend of admin.html by validating 
    how the input from the form is handled.
-->

<body>
    <?php
    require_once("../../db_connection.php");
    $search = $_POST['bsearch'];

    /*
    The condition statement below checks if the booking search input is empty.
    If there is no input, an SQL command that checks for bookings made within a 2-hour interval 
    is executed.
    Else if the input is not empty, a second SQL command will check for a specific booking that matches the 
    user input). 
    Both results are displayed using the <table> element.
    */

    if (empty($search)) {
        $sql = "SELECT * from bookings WHERE CAST(pickup_date as DATETIME) + CAST(pickup_time as DATETIME) BETWEEN NOW() AND NOW() + INTERVAL 2 HOUR";
        $result = mysqli_query($conn, $sql);
    ?>

        <?php
        if (mysqli_num_rows($result) > 0) { ?>
            <div id='table__container'>
                <table>
                    <tr>
                        <th>Booking Reference Number</th>
                        <th>Customer Name</th>
                        <th>Phone</th>
                        <th>Pickup Suburb</th>
                        <th>Destination Suburb</th>
                        <th>Pickup Date and Time</th>
                        <th>Status</th>
                    </tr>
                    <?php
                    while ($row = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td><?= $row['booking_ref_num'] ?></td>
                            <td><?= $row['customer_name'] ?></td>
                            <td><?= $row['phone_number'] ?></td>
                            <td><?= $row['suburb'] ?></td>
                            <td><?= $row['destination_suburb'] ?></td>
                            <td><?= date('d/m/Y', strtotime($row['pickup_date'])) . " " . date('H:i', strtotime($row['pickup_time'])) ?></td>
                            <td><?= $row['status'] ?></td>
                        </tr>
                    <?php
                    } // end of while loop
                    ?>
                </table>
            </div>
        <?php
        } // end of inner if
        else { ?>
            <text>There are no records of bookings in the next 2 hours</text>
        <?php
        } //end of outer if
    } else {
        $sql2 = "SELECT * from bookings where booking_ref_num LIKE '%$search%'";
        $result2 = mysqli_query($conn, $sql2);

        /*
        Display booking result for user search if there is any 
        */
        if (mysqli_num_rows($result2) > 0) { ?>
            <div id='table__container'>
                <table>
                    <tr>
                        <th>Booking Reference Number</th>
                        <th>Customer Name</th>
                        <th>Phone</th>
                        <th>Pickup Suburb</th>
                        <th>Destination Suburb</th>
                        <th>Pickup Date and Time</th>
                        <th>Status</th>
                        <th>Assign</th>
                    </tr>
                    <?php
                    while ($row = mysqli_fetch_assoc($result2)) { ?>
                        <tr>
                            <td><?= $row['booking_ref_num'] ?></td>
                            <td><?= $row['customer_name'] ?></td>
                            <td><?= $row['phone_number'] ?></td>
                            <td><?= $row['suburb'] ?></td>
                            <td><?= $row['destination_suburb'] ?></td>
                            <td><?= date('d/m/Y', strtotime($row['pickup_date'])) . " " . date('H:i', strtotime($row['pickup_time'])) ?></td>
                            <td><?= $row['status'] ?></td>
                        </tr>
                    <?php } // end of while loop
                    ?>
                </table>
            </div>
        <?php } // end of inner if
        else { ?>
            <text>There are no booking reference numbers that match "<?= $search ?>" in the system.</text>
        <?php } ?>
    <?php } // end of else 
    ?>
</body>

</html>