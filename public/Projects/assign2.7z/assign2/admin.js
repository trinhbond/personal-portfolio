var xhr = createRequest(); 
/*
    Name: Bond Trinh
    Student ID: 18026893

    This function retrieves the form input from admin.html and sends it to a
    dataSource (admin.php) wher the input is displayed on a div where and id is called
    "targetDiv".
*/
function getData(dataSource, divID, bsearch)  
{ 
    if(xhr) 
    { 
        var obj = document.getElementById(divID); 
        var requestbody ="bsearch="+encodeURIComponent(bsearch); 
        
        xhr.open("POST", dataSource, true); 
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); 
        xhr.onreadystatechange = function() 
        { 
            alert(xhr.readyState); // to let us see the state of the computation 
            if (xhr.readyState == 4 && xhr.status == 200) 
            { 
                obj.innerHTML = xhr.responseText; 
            } // end if 
        } // end anonymous call-back function 
        xhr.send(requestbody); 
    } // end if 
} // end function getData()