<?php

/*
    Name: Bond Trinh
    Student ID: 18026893

    This file creates a bookings table and makes booking entries when all the inputs
    the form are considered valid. 
*/

/* connecting to database server */
require_once("../../db_connection.php");

/* retrieve form input details */
$cname = $_POST['cname'];
$phone = $_POST['phone'];
$unumber = $_POST['unumber'];
$snumber = $_POST['snumber'];
$stname = $_POST['stname'];
$sbname = $_POST['sbname'];
$dsbname = $_POST['dsbname'];
$date = $_POST['date'];
$time = $_POST['time'];

/* 
    An array of boolean values to check for validity of inputs. 
    The array will be assigned a false value if any input from the form is invalid,
    other it will be set to true.
*/
$success[] = true;

/*
    Retrieving the current date and time to check against the Pickup-time
    and Pick-up Date. The user should not be able to make bookings before the current
    date.
*/
$date_now = date("Y-m-d");
$time_now = date("H:i");

echo "<br>";
echo "<div class='container'>";

if (!isset($cname) || (trim($cname) == "") || preg_match('/[0-9]/', $cname) || preg_match('/[\'^ $%&*()}{@#~?><>,|=_+ -]/', $cname)) {
    $success[] = false;
    echo "<text style='color: red;'>* Customer cannot be empty or contain numbers.</text><br>";
}

if (!isset($phone) || (trim($phone) == "") || preg_match('/[A-Za-z]/', $phone) || preg_match('/[\'^ $%&*()}{@#~?><>,|=_+ -]/', $phone)) {
    $success = false;
    echo "<text style='color: red;'>* Phone number cannot contain letters, symbols and cannot be blank.</text><br>";
}
if (strlen($phone) < 10 || (strlen($phone) > 12)) {
    $success = false;
    echo "<text style='color: red;'>* Phone number must be between 10-12 digits.</text><br>";
}

if (preg_match('/[A-Za-z]/', $unumber) || preg_match('/[\'^ $%&*()}{@#~?><>,|=_+ -]/', $unumber)) {
    $success = false;
    echo "<text style='color: red;'>* Unit number cannot contain letters or symbols and cannot be blank.</text><br>";
}

if (!isset($snumber) || (trim($snumber) == "") || preg_match('/[A-Za-z]/', $snumber) || preg_match('/[\'^ $%&*()}{@#~?><>,|=_+ -]/', $snumber)) {
    $success = false;
    echo "<text style='color: red;'>* Street number cannot contain letters or symbols and cannot be blank.</text><br>";
}

if (!isset($stname) || (trim($stname) == "") || preg_match('/[0-9]/', $stname) || preg_match('/[\'^ $%&*()}{@#~?><>,|=_+ -]/', $stname)) {
    $success = false;
    echo "<text style='color: red;'>* Street name cannot contain numbers or symbols and cannot be blank.</text><br>";
}

if (!isset($date) || (trim($date) == "")) {
    $success = false;
    echo "<text style='color: red;'>* You must specify a date.</text><br>";
}

if ($date < $date_now) {
    $success = false;
    echo "<text style='color: red;'>* The Pick-up Date cannot be before today's date.</text><br>";
}

if ($time < $time_now) {
    $success = false;
    echo "<text style='color: red;'>* The Pick-up Time cannot be before today's date.</text><br>";
}

if (!isset($time) || (trim($time) == "")) {
    $success = false;
    echo "<text style='color: red;'>* You must specify a time.</text><br>";
}

/* 
    Using str_pad to pad the letters "BRN" to the the beginning and specifying a max length
    of 8 for the booking reference variable.
    rand() is used to generate the random 5 digit number.
*/
$random_number = rand(0, 10000);
$unique_number_code = str_pad($random_number, 5, 0, STR_PAD_LEFT);
$booking_reference_number = str_pad($unique_number_code, 8, "BRN", STR_PAD_LEFT);
$final_date = date('d/m/Y', strtotime($date));

/*
    All input has successed validation and the booking will be created
*/
if ($success) {
    $success = true;

    $sql = "SELECT * from bookings";
    $result = $conn->query($sql);
    $status = "Unassigned";

    if ($result !== FALSE) {
        $sql_insert = "INSERT INTO bookings (booking_ref_num, customer_name, phone_number, unit_number, street_number, street_name, suburb, destination_suburb, pickup_date, pickup_time, status) 
	VALUES ('$booking_reference_number', '$cname', '$phone', '$unumber', '$snumber', '$stname', '$sbname', '$dsbname', '$date', '$time', '$status')";

        if ($conn->query($sql_insert) === TRUE) {

            echo "<h3 style='color: green;'>Thank you for your booking!</h3>";
            echo "<text style='color: green;'>Booking reference number: $booking_reference_number</text><br>";
            echo "<text style='color: green;'>Pickup time: $time</text><br>";
            echo "<text style='color: green;'>Pickup date: $final_date</text>";
        } else {
            echo "<text style='color: red;'>Error.</text><br>";
        }
    } else {
        $sql = "create table bookings(
            booking_ref_num VARCHAR(255),
            customer_name VARCHAR(255) NOT NULL,
            phone_number INT NOT NULL,
            unit_number INT,
            street_number INT NOT NULL,
            street_name VARCHAR(255) NOT NULL,
            suburb VARCHAR(255),
            destination_suburb VARCHAR(255),
            pickup_date DATE,
            pickup_time TIME,
            status VARCHAR(255),
            assign VARCHAR(255)
         );";

        if ($conn->query($sql) === TRUE) {
            echo "<text style='color: green;'>bookings table created!</text>";
        } else {
            echo "<text style='color: red;'>Error in creating table...</text>";
        }
    }
} else {
    $success = false;
}
echo "</div>";
