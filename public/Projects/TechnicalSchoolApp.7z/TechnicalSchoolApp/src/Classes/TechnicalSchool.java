package Classes;

/**
 * The TechnicalSchool stores the Semester 1 Module Offerings, and
 * includes constructors, and a method for a certification algorithm.
 * @author Bond Trinh 18026893
 **/

public class TechnicalSchool
{
    /**
     * The instance variable offerings stores the Semester 1 modules.
     */

    private Module[] offerings;

    private static Module[] semesterOneModuleOfferings()
    {
        Module[] semesterOneOfferings = new Module[13];

        semesterOneOfferings[0] = new Module("Programming", "PROG101", Level.ONE, ModuleType.TAUGHT);
        semesterOneOfferings[1] = new Module("Statistics", "STAT102", Level.ONE, ModuleType.TAUGHT);
        semesterOneOfferings[2] = new Module("Database Design", "DATA222", Level.TWO, ModuleType.TAUGHT);
        semesterOneOfferings[3] = new Module("Object-Oriented Programming", "PROG202", Level.TWO, ModuleType.TAUGHT);
        semesterOneOfferings[4] = new Module("Information Systems", "INSY313", Level.THREE, ModuleType.TAUGHT);
        semesterOneOfferings[5] = new Module("Web Services", "WEBS332", Level.THREE, ModuleType.TAUGHT);
        semesterOneOfferings[6] = new Module("Technology Applications", "TECH103", Level.ONE, ModuleType.SELF_STUDY);
        semesterOneOfferings[7] = new Module("Theory of Computation", "THEO111", Level.ONE, ModuleType.SELF_STUDY);
        semesterOneOfferings[8] = new Module("Model Checking", "MODC233", Level.TWO, ModuleType.SELF_STUDY);
        semesterOneOfferings[9] = new Module("Topology", "TOPG233", Level.TWO, ModuleType.SELF_STUDY);
        semesterOneOfferings[10] = new Module("Logic", "LOGI321", Level.THREE, ModuleType.SELF_STUDY);
        semesterOneOfferings[11] = new Module("Web App Dev", "PROJ399", Level.THREE, ModuleType.PROJECT);
        semesterOneOfferings[12] = new Module("Great Code Company", "EXTO396", Level.THREE, ModuleType.CLIENT_PROJECT);

        return (semesterOneOfferings);
    }

    /**
     * Default constructor to instantiate the offerings variable with appropriate Module objects.
     */

    public TechnicalSchool()
    {
        this.offerings = TechnicalSchool.semesterOneModuleOfferings();
    }

    /**
     * Get method for offerings variable.
     * @return Returns the offerings.
     */

    public Module[] getOfferings()
    {
        return (offerings);
    }

    /**
     *
     * @param code : The parameter code is used for searching through the array for a match.
     * @return The lookup Module returns a module with the matching code if it is found in the offerings array,
     * otherwise it returns nothing.
     */

    public Module lookup(String code)
    {
        for (int i = 0; i < offerings.length; i++)
        {
            if (code.equals(offerings[i].getCode()))
            {
                return (offerings[i]);
            }
        }
        return (null);
    }

    /**
     * @param student The isCertified method takes in a Student's transcript as input and determines if they are certified by a list of criteria's.
     * @return If a student meets the criteria in isCertified, the Boolean method returns true, otherwise false.
     **/

    public boolean isCertified(Student student)
    {
        // Variables to keep count of the 3 levels and whether or not the student fulfills the criteria.
        int level1 = 0, level2 = 0, level3 = 0;
        int projectModule = 0, taught = 0;
        boolean[] criteriaMet = new boolean[6];

        for (int i = 0; i < student.getTranscript().length; i++)
        {
            // Level 1 criteria
            if ((student.getTranscript()[i].getModule().getLevel() == Level.ONE) && (student.getTranscript()[i].getGrade().isPass() && (student.getTranscript()[i].getModule().getType() == ModuleType.SELF_STUDY) || (student.getTranscript()[i].getModule().getType() == ModuleType.TAUGHT)))
            {
                level1++;

                if (level1 >= 3)
                {
                    criteriaMet[0] = true;
                }
            }
            // Level 2 criteria
            else if ((student.getTranscript()[i].getModule().getLevel() == Level.TWO) && (student.getTranscript()[i].getGrade().isPass()))
            {
                level2++;

                if (level2 >= 3)
                {
                    criteriaMet[1] = true;
                }
                else if (student.getTranscript()[i].getModule().getType() == ModuleType.SELF_STUDY)
                {
                    criteriaMet[2] = true;
                }
            }
            // Level 3 criteria
            else if ((student.getTranscript()[i].getModule().getLevel() == Level.THREE) && (student.getTranscript()[i].getGrade().isPass()))
            {
                level3++;

                if (level3 >= 4)
                {
                    criteriaMet[3] = true;
                }
                else if ((student.getTranscript()[i].getModule().getType() == ModuleType.TAUGHT) && (taught >= 2))
                {
                    criteriaMet[4] = true;
                }
            }
            // Project module criteria
            else if ((student.getTranscript()[i].getModule().getType() == ModuleType.PROJECT) || (student.getTranscript()[i].getModule().getType() == ModuleType.CLIENT_PROJECT))
            {
                projectModule++;

                if (projectModule >= 1)
                {
                    criteriaMet[5] = true;
                }
            }
        }

        /**
         * An if statement to check if the student has fulfilled all of the criteria to be certified.
         * @Return returns true if the student has met all of the requirements, or false if the student has not.
         */

        if ((criteriaMet[0] = true) && (criteriaMet[1] = true) && (criteriaMet[2] = true) && (criteriaMet[3] = true) && (criteriaMet[4] = true) && (criteriaMet[5] = true) && (level1 >= 3) && (level2 >= 3) && (level3 >= 4))
        {
            return (true);
        }
        return (false);
    }
}