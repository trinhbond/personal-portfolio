package Classes;

/**
 * The Grade class maintains a list of Grade enum values with associated boundaries for each mark.
 * e.g. A+ = 100-90, A = 90-85, etc...
 *
 * The class is also populated with 4 variables, with an appropriate constructor to initialise the variables, and with getters and setters.
 * printGrade (Type String, to represent the Grade), low (Type int , to represent the low boundary mark for a student),
 * high (Type int, to represent the high boundary mark for a student), pass (Type boolean, to return a pass of fail).
 *
 * The class contains a method which returns a boolean value if the student does or does not pass.
 * @author Bond Trinh 18026893
 **/

public enum Grade
{
    A_PLUS(100, 90, true, "A+"), A(90, 85, true, "A"), A_MINUS(85, 80, true, "A-"), B_PLUS(80, 75, true, "B+"),	B(75, 70, true, "B"), B_MINUS(70, 65, true, "B-"), C_PLUS(65, 60, true, "C+"), C(60, 55, true, "C"), C_MINUS(55, 50, true, "C-"), D(49, 0, false, "D");

    private String printGrade;
    private int minRange;
    private int maxRange;
    private boolean pass;

    Grade(int maxRange, int minRange, boolean pass, String printGrade)
    {
        this.maxRange = maxRange;
        this.minRange = minRange;
        this.pass = pass;
        this.printGrade = printGrade;
    }

    /**
     * @return Returns a boolean value indicating whether the student passed or failed.
     *
     * The method contains a condition which reflects whether or not a student has passed with a mark of at least 50,
     * or 100 at most.
     * If this is true, the method returns true, otherwise false.
     **/

    public boolean isPass()
    {
        if ((this.minRange >= 50) && (this.maxRange <= 100))
        {
            return (this.pass);
        }
        return (false);
    }

    /**
     * @return text representing the Grade of a student.
     **/

    public String toString()
    {
        return (this.printGrade);
    }
}