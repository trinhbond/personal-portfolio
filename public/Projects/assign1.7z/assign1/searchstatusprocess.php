<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>Search Status Process</title>
    <style type="text/css">
        * {
            margin: 0;
            font-family: 'Montserrat', sans-serif;
        }

        html {
            height: 100%;
        }

        body {
            min-height: 100%;
        }

        .container-fluid {
            width: 100%;
        }

        ul {
            padding-top: 5%;
            padding-bottom: 5%;
            font-weight: bold;
        }

        .nav {
            background-color: transparent;
            position: relative;
            padding: 25px 0 25px 0;
            background-color: rgba(220, 220, 220, 0);
            width: 96%;
            height: auto;
            display: flex;
            margin-left: auto;
            margin-right: auto;
            left: 0;
            right: 0;
        }

        li {
            display: inline;
            margin-right: 14px;
        }

        .nav-item {
            font-size: 16px;
        }

        .nav-link {
            color: black;
            font-weight: 600;
        }

        .nav-link:hover {
            text-decoration: underline;
            text-underline-offset: 5px;
        }

        .content {
            width: 96%;

            position: absolute;
            margin-left: auto;
            margin-right: auto;
            left: 0;
            right: 0;
            justify-content: center;
            background-color: beige;
            padding: 25px 25px 25px 25px;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/index.html">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/about.html">About this assignment</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/poststatusform.php">Post a new status</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/searchstatusform.html">Search a post</a>
            </li>
        </ul>
    </div>
    <div class="content">
        <?php
        require_once("../../db_connection.php");

        $search = $_POST["Search"];

        echo "Your search: $search";

        if (trim($search) == '' || empty($search)) {
        ?>
            <h1>You did not enter a search string. Please try again.</h1>
            <?
        } else {
            $sql_query = "SELECT statuscode, status, share, date, permission FROM posts WHERE status LIKE '%$search%'";
            $result = $conn->query($sql_query);


            if (mysqli_num_rows($result) > 0) {
                while ($row = $result->fetch_assoc()) {
            ?>
                    <div class="querycontainer" style=" width: auto; border: 1px solid black; margin-top: 15px; padding: 10px 10px 10px 10px;">
                        <h2>Status Information</h2>
                        <p>Status: <?= $row['status'] ?><br>
                            Status Code: <?= $row['statuscode'] ?></p>
                        <p>Share: <?= $row['share'] ?><br>
                            Date: <?= date('F d, Y', strtotime($row['date'])) ?><br>
                            Permission: <?= $row['permission'] ?>
                        </p>
                    </div>
                <?
                }
            } else if (mysqli_num_rows($result) == 0) {
                ?>
                <h1>Your search query did not match anything in the database.</h1>
        <?            }
        }



        ?>
        <br>
        <a href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/searchstatusform.html">Search for another status</a>
        <a href="http://dmr1412.cmslamp14.aut.ac.nz/assign1/about.html" style="float:right;">Return to Home Page</a>

    </div>
</body>

</html>